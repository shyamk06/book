const express = require('express');
const router = express.Router();
const Book = require('../models/Book');

// POST create book
router.post('/', async (req, res, next) => {
  try {
    const { title, author, publishedYear, genre } = req.body;
    const newBook = new Book({ title, author, publishedYear, genre });
    const savedBook = await newBook.save();
    res.status(201).json(savedBook);
  } catch (err) {
    next(err);
  }
});

// GET all books
router.get('/', async (req, res, next) => {
  try {
    const books = await Book.find();
    res.json(books);
  } catch (err) {
    next(err);
  }
});

// GET book by ID
router.get('/:id', async (req, res, next) => {
  try {
    const book = await Book.findById(req.params.id);
    if (!book) {
      const error = new Error('Book not found');
      error.statusCode = 404;
      throw error;
    }
    res.json(book);
  } catch (err) {
    // Handle invalid ObjectId error from mongoose
    if (err.kind === 'ObjectId') {
      err.statusCode = 400;
      err.message = 'Invalid book ID';
    }
    next(err);
  }
});

// PUT update book by ID
router.put('/:id', async (req, res, next) => {
  try {
    const { title, author, publishedYear, genre } = req.body;
    const updatedBook = await Book.findByIdAndUpdate(
      req.params.id,
      { title, author, publishedYear, genre },
      { new: true, runValidators: true }
    );
    if (!updatedBook) {
      const error = new Error('Book not found');
      error.statusCode = 404;
      throw error;
    }
    res.json(updatedBook);
  } catch (err) {
    if (err.kind === 'ObjectId') {
      err.statusCode = 400;
      err.message = 'Invalid book ID';
    }
    next(err);
  }
});

// DELETE book by ID
router.delete('/:id', async (req, res, next) => {
  try {
    const deletedBook = await Book.findByIdAndDelete(req.params.id);
    if (!deletedBook) {
      const error = new Error('Book not found');
      error.statusCode = 404;
      throw error;
    }
    res.json({ message: 'Book deleted successfully' });
  } catch (err) {
    if (err.kind === 'ObjectId') {
      err.statusCode = 400;
      err.message = 'Invalid book ID';
    }
    next(err);
  }
});

module.exports = router;
