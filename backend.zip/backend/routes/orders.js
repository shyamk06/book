const express = require('express');
const router = express.Router();
const Order = require('../models/Order');
const { protect } = require('../middleware/auth');

// 🆕 Create order
router.post('/', protect, async (req, res, next) => {
  const { books, total } = req.body;

  try {
    const order = await Order.create({
      user: req.user._id,
      books,
      total
    });

    res.status(201).json(order);
  } catch (err) {
    next(err);
  }
});

// 🆕 Get user's orders
router.get('/my', protect, async (req, res, next) => {
  try {
    const orders = await Order.find({ user: req.user._id }).populate('books');
    res.json(orders);
  } catch (err) {
    next(err);
  }
});

module.exports = router;
